please credit ust, midi, and tuning (if tuned ustx) to "your house." (or voizuu if you'd prefer)

inst: https://youtu.be/7lw8Axg_Azo


- Creator Links -
Twitter: https://twitter.com/voizuu
Youtube: https://www.youtube.com/channel/UCFRidNJ_6mkyF9pzu9jlRyg