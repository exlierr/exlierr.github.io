please credit ust and midi to "your house." (or voizuu if you'd prefer.) and tuning (if tuned ustx) to "harunoyuki"

inst: https://piapro.jp/t/5Lar


- Creator Links -
Twitter: https://twitter.com/voizuu
Youtube: https://www.youtube.com/channel/UCFRidNJ_6mkyF9pzu9jlRyg

Twitter: [requested blank]
Youtube: [requested blank]

Contributor's Note: "I'm not really comfortable with showing my socials as of now, but that may change in the future."
Please quote: "Due to personal reasons I've requested that my social media presence be excluded, this is subject to change with time."