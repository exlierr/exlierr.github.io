please credit ust, midi, and tuning to "liure"

inst: https://youtu.be/Oc88e0SXc8Y


- Creator Links -
Twitter: https://twitter.com/liure_bkr
Youtube: https://www.youtube.com/c/liure